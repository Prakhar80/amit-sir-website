from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from datetime import datetime

app = FastAPI(title="LitCindore Backend API", version="1.0.0")

# CORS middleware - Allow frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Email Configuration
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "contact@litcindore.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "contact@litcindore.com")

# Pydantic models for request validation
class ContactMessage(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None
    message: str

class CourseEnrollment(BaseModel):
    name: str
    email: EmailStr
    phone: str
    course: str
    experience: Optional[str] = None
    message: Optional[str] = None

class CourseEnquiry(BaseModel):
    name: str
    email: EmailStr
    phone: str
    course: str
    message: Optional[str] = None

class CampusVisit(BaseModel):
    name: str
    email: EmailStr
    phone: str
    date: str
    time: str
    message: Optional[str] = None

# Email sending function
def send_email(subject: str, body: str, to_email: str = None):
    """Send email using SMTP"""
    try:
        if not SMTP_PASSWORD:
            raise Exception("SMTP password not configured")
        
        msg = MIMEMultipart('alternative')
        msg['From'] = SMTP_USER
        msg['To'] = to_email or ADMIN_EMAIL
        msg['Subject'] = subject
        
        # Create HTML version
        html_body = f"""
        <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <div style="max-width: 600px; margin: 0 auto; border: 1px solid #ddd; border-radius: 8px; padding: 20px;">
                    <h2 style="color: #2563eb; margin-bottom: 20px;">LitCindore - New Submission</h2>
                    {body}
                    <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">
                    <p style="color: #666; font-size: 12px;">
                        Received: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}<br>
                        Website: <a href="https://litcindore.com">litcindore.com</a>
                    </p>
                </div>
            </body>
        </html>
        """
        
        msg.attach(MIMEText(html_body, 'html'))
        
        # Send email
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        
        return True
    except Exception as e:
        print(f"Email error: {str(e)}")
        return False

# API Endpoints

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "online",
        "message": "LitCindore Backend API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "smtp_configured": bool(SMTP_PASSWORD),
        "smtp_host": SMTP_HOST,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/contact-message")
async def contact_message(data: ContactMessage):
    """Handle contact form submissions"""
    try:
        body = f"""
        <h3>Contact Form Submission</h3>
        <p><strong>Name:</strong> {data.name}</p>
        <p><strong>Email:</strong> {data.email}</p>
        <p><strong>Phone:</strong> {data.phone or 'Not provided'}</p>
        <p><strong>Message:</strong></p>
        <p style="background: #f5f5f5; padding: 15px; border-radius: 5px;">{data.message}</p>
        """
        
        success = send_email(
            subject=f"Contact Form: {data.name}",
            body=body
        )
        
        if success:
            return {"success": True, "message": "Message sent successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to send email")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/course-enrollment")
async def course_enrollment(data: CourseEnrollment):
    """Handle course enrollment submissions"""
    try:
        body = f"""
        <h3>Course Enrollment Request</h3>
        <p><strong>Name:</strong> {data.name}</p>
        <p><strong>Email:</strong> {data.email}</p>
        <p><strong>Phone:</strong> {data.phone}</p>
        <p><strong>Course:</strong> {data.course}</p>
        <p><strong>Experience:</strong> {data.experience or 'Not provided'}</p>
        <p><strong>Message:</strong></p>
        <p style="background: #f5f5f5; padding: 15px; border-radius: 5px;">{data.message or 'No additional message'}</p>
        """
        
        success = send_email(
            subject=f"Course Enrollment: {data.course}",
            body=body
        )
        
        if success:
            return {"success": True, "message": "Enrollment request sent successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to send email")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/course-enquiry")
async def course_enquiry(data: CourseEnquiry):
    """Handle course enquiry submissions"""
    try:
        body = f"""
        <h3>Course Enquiry</h3>
        <p><strong>Name:</strong> {data.name}</p>
        <p><strong>Email:</strong> {data.email}</p>
        <p><strong>Phone:</strong> {data.phone}</p>
        <p><strong>Course:</strong> {data.course}</p>
        <p><strong>Message:</strong></p>
        <p style="background: #f5f5f5; padding: 15px; border-radius: 5px;">{data.message or 'No additional message'}</p>
        """
        
        success = send_email(
            subject=f"Course Enquiry: {data.course}",
            body=body
        )
        
        if success:
            return {"success": True, "message": "Enquiry sent successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to send email")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/campus-visit")
async def campus_visit(data: CampusVisit):
    """Handle campus visit requests"""
    try:
        body = f"""
        <h3>Campus Visit Request</h3>
        <p><strong>Name:</strong> {data.name}</p>
        <p><strong>Email:</strong> {data.email}</p>
        <p><strong>Phone:</strong> {data.phone}</p>
        <p><strong>Preferred Date:</strong> {data.date}</p>
        <p><strong>Preferred Time:</strong> {data.time}</p>
        <p><strong>Message:</strong></p>
        <p style="background: #f5f5f5; padding: 15px; border-radius: 5px;">{data.message or 'No additional message'}</p>
        """
        
        success = send_email(
            subject=f"Campus Visit Request: {data.name}",
            body=body
        )
        
        if success:
            return {"success": True, "message": "Visit request sent successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to send email")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
