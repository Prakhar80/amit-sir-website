(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,37273,e=>{"use strict";var t=e.i(43476),n=e.i(71645);e.s(["default",0,()=>{let[e,a]=(0,n.useState)(!1),[r,s]=(0,n.useState)([]),[i,o]=(0,n.useState)(""),[l,c]=(0,n.useState)(!1),[d,u]=(0,n.useState)(null),[m,p]=(0,n.useState)("name"),h=(0,n.useRef)(null),f={"RHCSA Certification":{fee:15e3,duration:45,demand:"Very High",salary:"₹6-12 LPA",difficulty:"Medium",placement:95},"AWS Solutions Architect":{fee:18e3,duration:40,demand:"Extremely High",salary:"₹8-20 LPA",difficulty:"Medium-Hard",placement:98},"Docker & Kubernetes":{fee:2e4,duration:30,demand:"Very High",salary:"₹7-15 LPA",difficulty:"Medium",placement:92},"Python Full Stack":{fee:25e3,duration:60,demand:"Extremely High",salary:"₹5-18 LPA",difficulty:"Medium",placement:96},"CCNA Networking":{fee:15e3,duration:50,demand:"High",salary:"₹4-10 LPA",difficulty:"Medium",placement:88},"DevOps with Azure":{fee:4e4,duration:60,demand:"Very High",salary:"₹8-16 LPA",difficulty:"Medium-Hard",placement:94},"RHCE Certification":{fee:15e3,duration:35,demand:"Very High",salary:"₹8-15 LPA",difficulty:"Medium-Hard",placement:92},Terraform:{fee:15e3,duration:25,demand:"Very High",salary:"₹10-18 LPA",difficulty:"Medium",placement:90},"DevOps AWS + AI":{fee:6e4,duration:50,demand:"Ultra High",salary:"₹12-25 LPA",difficulty:"Hard",placement:96}},y=[{question:"What courses do you offer?",answer:"We offer comprehensive IT training courses including:\n• RHCSA/RHCE (Red Hat Linux)\n• AWS Cloud Computing\n• Docker & Kubernetes\n• Python Full Stack Development\n• CCNA Networking\n• DevOps with Azure (AZ-400)\n• Terraform Infrastructure as Code\n• DevOps with AWS + AI\n• Digital Marketing\n• C/C++, Java, PHP\n• Hardware & Networking",keywords:["courses","training","what do you offer","programs","subjects","learn"]},{question:"What are your course fees?",answer:"Our course fees vary by program:\n• RHCSA Certification: ₹15,000 (45 days)\n• RHCE Certification: ₹15,000 (35 days)\n• AWS Solutions Architect: ₹18,000 (40 days)\n• Docker & Kubernetes: ₹20,000 (30 days)\n• Python Full Stack: ₹25,000 (60 days)\n• CCNA Networking: ₹15,000 (50 days)\n• Terraform: ₹15,000 (25 days)\n• DevOps with Azure: ₹40,000 (60 days)\n• DevOps AWS + AI: ₹60,000 (50 days)\n\nWe also offer flexible payment options and student discounts!",keywords:["fees","cost","price","payment","money","charges","expensive"]},{question:"Where are you located?",answer:"📍 LITC Infotech is located at:\nGround Floor, Metro Tower\nNear Mangal City, Behind Tinku Cafe\nIndore, MP, India - 452001\n\n📞 Contact: +91-9522220892\n✉️ Email: info@litcindore.com",keywords:["location","address","where","contact","phone","email","indore"]},{question:"Do you provide job placement?",answer:"Yes! We provide 100% placement assistance including:\n• Resume building and optimization\n• Interview preparation sessions\n• Direct company tie-ups\n• Job referrals and recommendations\n• Career counseling and guidance\n• Industry networking opportunities\n\nOur students work at top companies like TCS, Infosys, Wipro, and many more!",keywords:["placement","job","career","employment","hiring","work"]},{question:"What are the class timings?",answer:"We offer flexible timing options:\n\n🕘 Weekend Batches:\n• Saturday-Sunday: 9:00 AM - 11:00 AM\n• Saturday-Sunday: 8:00 PM - 10:00 PM\n\n🕘 Weekday Batches:\n• Monday-Friday: 8:30 AM - 10:30 AM\n• Monday-Friday: 6:00 PM - 8:00 PM\n\nSpecial timings available for working professionals!",keywords:["timing","schedule","class","time","when","hours","weekend","weekday"]},{question:"Do you provide online classes?",answer:"Yes! We offer both online and offline training modes:\n\n💻 Online Features:\n• Live interactive sessions\n• Recorded lectures for revision\n• Virtual labs and hands-on practice\n• One-on-one doubt clearing\n• Digital study materials\n\n🏢 Offline Features:\n• Physical classroom training\n• Direct interaction with instructors\n• Lab facilities with latest equipment\n• Group discussions and activities",keywords:["online","offline","virtual","remote","classroom","mode"]},{question:"What certifications will I get?",answer:"You'll receive multiple certifications:\n\n🏆 Industry Certifications:\n• Red Hat Certified (RHCSA/RHCE)\n• AWS Certified Solutions Architect\n• Cisco CCNA\n• Docker Certified Associate\n• Python Institute Certifications\n\n🎓 LITC Certifications:\n• Course completion certificates\n• Project completion certificates\n• Skill assessment certificates\n\nAll certifications are globally recognized!",keywords:["certificate","certification","degree","qualification","credential"]},{question:"Who are your instructors?",answer:"Our expert faculty includes:\n\n👨‍🏫 Ram Sir - Lead Instructor:\n• 15+ years industry experience\n• Red Hat Certified Architect\n• AWS Solutions Architect\n• Docker & Kubernetes Expert\n\n👩‍🏫 Expert Faculty Team:\n• Industry professionals\n• Multiple certifications\n• Real-world project experience\n• Dedicated to student success\n\nAll instructors are certified and experienced professionals!",keywords:["instructor","teacher","faculty","trainer","staff","ram sir"]},{question:"How to enroll or register?",answer:"Easy enrollment process:\n\n📞 Call us: +91-9522220892\n💬 WhatsApp: +91-9522220892\n✉️ Email: info@litcindore.com\n🏢 Visit: Metro Tower, Indore\n\n📋 Required Documents:\n• Educational certificates\n• ID proof (Aadhar/PAN)\n• Passport size photos\n• Fee payment receipt\n\nWe'll guide you through the entire process!",keywords:["enroll","register","admission","join","apply","signup"]},{question:"Do you provide study materials?",answer:"Yes! Comprehensive study materials included:\n\n📚 What you get:\n• Detailed course handbooks\n• Video tutorials and recordings\n• Lab practice guides\n• Exam preparation materials\n• Industry case studies\n• Project templates\n\n💻 Digital Resources:\n• Online portal access\n• Practice tests and quizzes\n• Code repositories\n• Reference documentation\n\nAll materials are regularly updated!",keywords:["study material","books","notes","resources","handouts","materials"]}],g={id:"1",text:"👋 Hey there! Welcome to LITC INFOTECH!\n\n🤖 I'm LITC Siri - your smart career advisor!\n\nBefore we start exploring amazing career opportunities, I'd love to know you better! 😊\n\n� **Please tell me your name:**",isBot:!0,timestamp:new Date};(0,n.useEffect)(()=>{0===r.length&&s([g])},[]),(0,n.useEffect)(()=>{h.current?.scrollIntoView({behavior:"smooth"})},[r]);let x=async()=>{if(!i.trim())return;let e={id:Date.now().toString(),text:i,isBot:!1,timestamp:new Date};if(s(t=>[...t,e]),o(""),c(!0),"name"===m)return void setTimeout(()=>{u({name:i,email:""});let e={id:(Date.now()+1).toString(),text:`Nice to meet you, ${i}! 😊

📧 **Now, please share your email address:**

(We'll use this to send you course details and updates)`,isBot:!0,timestamp:new Date};s(t=>[...t,e]),p("email"),c(!1)},800);if("email"===m){if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(i))return void setTimeout(()=>{let e={id:(Date.now()+1).toString(),text:`Oops! 😅 That doesn't look like a valid email address.

📧 **Please enter a valid email** (e.g., name@example.com):`,isBot:!0,timestamp:new Date};s(t=>[...t,e]),c(!1)},800);let e=async()=>{try{let e=await fetch("/api/chatbot-enquiry",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:d?.name,email:i})});await e.json()}catch(e){}};return void setTimeout(async()=>{u(e=>e?{...e,email:i}:{name:"",email:i}),e();let t={id:(Date.now()+1).toString(),text:`Perfect! ✅ Thank you, ${d?.name}!

🎉 **Your details are saved:**
📛 Name: ${d?.name}
📧 Email: ${i}

✉️ **Our team has been notified and will contact you soon!**

━━━━━━━━━━━━━━━━━━━━

🧠 Now I'm ready to help you! I can:
• Analyze courses and recommend the BEST one for YOU
• Compare salaries, placements, and career growth
• Find budget-friendly options that fit your needs
• Suggest quick certification paths
• Give real-time job market insights

💬 **Talk to me naturally!** Ask things like:
"Which course is best for me?", "What salary can I expect?", "Show me affordable courses"

🚀 Ready to find your perfect tech career path? Let's chat! 😊`,isBot:!0,timestamp:new Date};s(e=>[...e,t]),p("done"),c(!1)},1e3)}setTimeout(()=>{let e=(e=>{let t=e.toLowerCase();for(let e of[{patterns:["best course","which course","recommend course","top course","popular course","good course"],response:()=>`🎯 Based on our placement data and industry demand, here are the TOP 3 courses I recommend:

`+Object.entries(f).sort((e,t)=>t[1].placement-e[1].placement).slice(0,3).map((e,t)=>`${t+1}. **${e[0]}** 🏆
   💰 Fee: ₹${e[1].fee.toLocaleString()}
   📅 Duration: ${e[1].duration} days
   📈 Market Demand: ${e[1].demand}
   💼 Expected Salary: ${e[1].salary}
   🎯 Placement Rate: ${e[1].placement}%
`).join("\n")+`
💡 **My Analysis**: AWS Solutions Architect has the highest placement rate and salary potential, perfect for cloud career!

Which one interests you most? I can provide detailed information! 😊`},{patterns:["salary","package","pay","earning","income","money"],response:()=>`💰 **Salary Analysis Based on Market Research:**

`+Object.entries(f).sort((e,t)=>parseInt(t[1].salary.split("-")[1])-parseInt(e[1].salary.split("-")[1])).map((e,t)=>`${t+1}. ${e[0]}: ${e[1].salary}
`).join("")+`
🔥 **Hot Tip**: Cloud technologies (AWS, DevOps) offer the highest salaries!
`+`📊 **Average Growth**: 15-25% salary hike after certification

`+`Which salary range are you targeting? I can suggest the perfect course! 🎯`},{patterns:["cheap","affordable","budget","low cost","minimum fee","less money"],response:()=>`💵 **Budget-Friendly Options (Best Value for Money):**

`+Object.entries(f).sort((e,t)=>e[1].fee-t[1].fee).slice(0,3).map((e,t)=>`${t+1}. **${e[0]}**
   💰 Fee: ₹${e[1].fee.toLocaleString()} (${e[1].duration} days)
   💼 Expected Salary: ${e[1].salary}
   📊 ROI: ${Math.round(1e5*parseInt(e[1].salary.split("-")[0])/e[1].fee)}x return
`).join("\n")+`
🎯 **Smart Choice**: Docker & Kubernetes offers excellent ROI at just ₹20,000!
`+`💡 **Pro Tip**: We offer EMI options and student discounts too!

Interested in any of these? 😊`},{patterns:["quick","fast","short","less time","duration","how long"],response:()=>`⚡ **Quick Certification Courses (Fast Track to Success):**

`+Object.entries(f).sort((e,t)=>e[1].duration-t[1].duration).slice(0,3).map((e,t)=>`${t+1}. **${e[0]}**
   ⏱️ Duration: ${e[1].duration} days
   💰 Fee: ₹${e[1].fee.toLocaleString()}
   🎯 Placement Rate: ${e[1].placement}%
`).join("\n")+`
🚀 **Fast Track Special**: Docker & Kubernetes - Get certified in just 30 days!
`+`📅 **Flexible Timing**: Weekend batches available for working professionals

Ready to start quickly? 😊`},{patterns:["easy","difficult","hard","beginner","advanced","level"],response:()=>`📚 **Course Difficulty Levels & My Recommendations:**

**🟢 Beginner-Friendly:**
• Python Full Stack - Perfect for coding beginners
• RHCSA Certification - Great Linux starting point

**🟡 Intermediate Level:**
• Docker & Kubernetes - Some tech background helpful
• CCNA Networking - Basic networking knowledge plus

**🔴 Advanced Level:**
• AWS Solutions Architect - Cloud experience preferred
• DevOps with Ansible - Multiple tech stack knowledge

💡 **My Suggestion**: Start with your current skill level, we provide complete support!
👨‍🏫 **Instructor Support**: Ram Sir personally guides every student

What's your current experience level? 😊`},{patterns:["job","placement","hiring","market","demand","opportunities"],response:()=>`📈 **Live Job Market Analysis (Updated This Month):**

`+Object.entries(f).sort((e,t)=>t[1].placement-e[1].placement).map((e,t)=>`${t+1}. **${e[0]}**
   🎯 Placement Rate: ${e[1].placement}%
   📊 Market Demand: ${e[1].demand}
   💼 Avg. Salary: ${e[1].salary}
`).join("\n")+`
🔥 **Hot Jobs Right Now:**
`+`• Cloud Engineers (AWS) - 500+ openings
`+`• DevOps Engineers - 300+ openings
`+`• Python Developers - 800+ openings

`+`💼 **Our Placement Partners**: TCS, Infosys, Wipro, Accenture, and 50+ more!
`+`🎯 **Success Rate**: 96% students get placed within 3 months

Ready to join the success story? 😊`}])for(let n of e.patterns)if(t.includes(n))return e.response();let n=null,a=0;for(let e of y){let r=0;for(let n of(t.includes(e.question.toLowerCase())&&(r+=15),e.keywords))t.includes(n.toLowerCase())&&(r+=3);let s=e.question.toLowerCase().split(" "),i=t.split(" ");for(let e of s)for(let t of i)e.includes(t)&&t.length>2&&(r+=2);r>a&&(a=r,n=e)}return n&&a>2?n.answer:t.includes("hello")||t.includes("hi")||t.includes("hey")?"Hello! 👋 I'm LITC Siri, your smart career advisor!\n\n🎯 I can help you with:\n• Finding the BEST course for your goals\n• Salary and placement analysis\n• Budget-friendly recommendations\n• Quick certification paths\n\nWhat's your career goal? Let's find the perfect course! 😊":t.includes("thank")||t.includes("thanks")?"You're absolutely welcome! 😊\n\n🌟 Remember: Your success is our mission!\n📞 Need immediate help? Call +91-9522220892\n\nAny other questions about your tech career journey? I'm here to guide you! 🚀":t.includes("bye")||t.includes("goodbye")?"Goodbye! 👋\n\n🎯 Before you go:\n• Book a FREE consultation: +91-9522220892\n• Visit us: Metro Tower, Indore\n• Follow up: info@litcindore.com\n\n🌟 Your tech career transformation awaits! See you soon! ✨":`🤔 I want to give you the PERFECT answer! Let me help you better:

💡 **Try asking me:**
• "Which is the best course for me?"
• "What salary can I expect?"
• "Show me budget-friendly courses"
• "Which course has best placements?"
• "I want quick certification"

🎯 **Or tell me about:**
• Your career goals
• Your budget range
• Your experience level
• Timeline preferences

💬 I'm designed to understand natural conversation - just ask me anything! 😊

📞 **Urgent help?** Call +91-9522220892 right now!`})(i),t={id:(Date.now()+1).toString(),text:e,isBot:!0,timestamp:new Date};s(e=>[...e,t]),c(!1)},1e3)};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50",children:(0,t.jsxs)("button",{onClick:()=>a(!e),className:"group relative bg-gradient-to-r from-blue-500 to-purple-600 text-white p-3 md:p-4 rounded-full shadow-2xl hover:scale-110 transition-all duration-300 animate-bounce",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("span",{className:"text-xl md:text-2xl",children:"🤖"}),(0,t.jsx)("span",{className:"font-semibold text-xs md:text-sm hidden sm:block",children:"LITC Siri"})]}),(0,t.jsx)("div",{className:"absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-pulse",children:"1"}),(0,t.jsx)("div",{className:"absolute inset-0 rounded-full bg-white/20 scale-0 group-hover:scale-150 transition-transform duration-500 opacity-0 group-hover:opacity-100"})]})}),e&&(0,t.jsxs)("div",{className:"fixed bottom-24 right-2 md:right-6 w-[calc(100vw-16px)] md:w-96 h-[70vh] md:h-[600px] max-h-[600px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col z-50 animate-fade-in-up",children:[(0,t.jsxs)("div",{className:"bg-gradient-to-r from-blue-600 to-purple-600 p-4 rounded-t-2xl flex items-center justify-between",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)("div",{className:"w-10 h-10 bg-white/20 rounded-full flex items-center justify-center",children:(0,t.jsx)("span",{className:"text-xl",children:"🤖"})}),(0,t.jsx)("div",{className:"absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"font-bold text-white",children:"LITC Siri"}),(0,t.jsx)("p",{className:"text-white/80 text-xs",children:"AI Assistant • Online"})]})]}),(0,t.jsx)("button",{onClick:()=>a(!1),className:"text-white/80 hover:text-white transition-colors text-xl",children:"✕"})]}),(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50",children:[r.map(e=>(0,t.jsx)("div",{className:`flex ${e.isBot?"justify-start":"justify-end"}`,children:(0,t.jsxs)("div",{className:`max-w-[80%] p-3 rounded-2xl ${e.isBot?"bg-white text-gray-800 shadow-md":"bg-gradient-to-r from-blue-500 to-purple-600 text-white"}`,children:[(0,t.jsx)("p",{className:"text-sm whitespace-pre-line",children:e.text}),(0,t.jsx)("p",{className:`text-xs mt-1 ${e.isBot?"text-gray-500":"text-white/70"}`,children:e.timestamp.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]})},e.id)),l&&(0,t.jsx)("div",{className:"flex justify-start",children:(0,t.jsx)("div",{className:"bg-white p-3 rounded-2xl shadow-md",children:(0,t.jsxs)("div",{className:"flex space-x-1",children:[(0,t.jsx)("div",{className:"w-2 h-2 bg-gray-400 rounded-full animate-bounce"}),(0,t.jsx)("div",{className:"w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:0.1s]"}),(0,t.jsx)("div",{className:"w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:0.2s]"})]})})}),(0,t.jsx)("div",{ref:h})]}),r.length<=1&&"done"===m&&(0,t.jsxs)("div",{className:"p-3 border-t bg-white",children:[(0,t.jsx)("p",{className:"text-xs text-gray-500 mb-2",children:"Quick questions:"}),(0,t.jsx)("div",{className:"flex flex-wrap gap-1",children:["Which is the best course for me?","Show me high salary courses","What are budget-friendly options?","Quick certification courses?","Job placement success rate?"].map((e,n)=>(0,t.jsx)("button",{onClick:()=>o(e),className:"text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full hover:bg-blue-200 transition-colors",children:e},n))})]}),(0,t.jsx)("div",{className:"p-4 border-t bg-white rounded-b-2xl",children:(0,t.jsxs)("div",{className:"flex gap-2",children:[(0,t.jsx)("textarea",{value:i,onChange:e=>o(e.target.value),onKeyPress:e=>{"Enter"!==e.key||e.shiftKey||(e.preventDefault(),x())},placeholder:"name"===m?"Type your name here...":"email"===m?"Type your email here...":"Ask me anything about LITC Infotech...",className:"flex-1 p-3 border border-gray-300 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm text-gray-900 placeholder-gray-500 bg-white",rows:1}),(0,t.jsx)("button",{onClick:x,disabled:!i.trim()||l,className:"bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-3 rounded-xl hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:(0,t.jsx)("span",{className:"text-lg",children:"📤"})})]})})]})]})}])},15161,e=>{e.n(e.i(37273))}]);